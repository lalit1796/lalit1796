'use strict';

angular.module('roompapaApp.admin', ['roompapaApp.auth', 'ngRoute']);

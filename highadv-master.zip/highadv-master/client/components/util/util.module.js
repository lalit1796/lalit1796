'use strict';

angular.module('roompapaApp.util', []);
